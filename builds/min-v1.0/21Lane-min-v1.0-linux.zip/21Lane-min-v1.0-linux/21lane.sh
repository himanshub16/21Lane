nohup python3 ftpserver.py &
exit 
