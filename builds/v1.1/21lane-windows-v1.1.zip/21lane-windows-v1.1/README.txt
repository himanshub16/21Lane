***********************************************************
*   _________                                  _______    *
*   |        | |  |           /\     |\     | |           *
*   |       /  |  |          /  \    | \    | |           *
*         /    |  |         /    \   |  \   | |_______    *
*       /      |  |        /______\  |   \  | |           *
*     /        |  |        /      \  |    \ | |           *
*    /________ |  |______ /        \ |     \| |_______    *
*                                                         *
***********************************************************

** STEPS TO INSTALL AND USE **
******************************

* Extract the zip to any place you want. You have already done that.
* If Python 3.5+ is not installed on your system, install it.
  The link is available on the same page you downloaded this software from.
* While installing Python, add Python to your path.
* Double click on "install.bat" file.
* The installer will do the rest of the job.

* After installation is complete, a shortcut is created on desktop as
  well as the start menu.

* Exchange URL : You can find it on your exchange's website.

* To know what's happening with your share in real time, 
  execute the following commands in command prompt:
  
     cd %userprofile%\21Lane\
	 monitor-log.bat

HAPPY SHARING.

https://21lane.github.io/