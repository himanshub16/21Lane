#!/bin/bash

tail -n 20 -f log.txt